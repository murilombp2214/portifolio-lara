﻿using Portifolio.Lulu.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Portifolio.Lulu.Domain.Services
{
    public class SendEmailService : ISendEmailService
    {
        private const string MyEmail = "portifolio.lulu@gmail.com";
        public void SendEmail(string email, string message)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(message))
                throw new Exception("O email ou a mensagem esta vazio");
            if(new MailAddress(email).Address != email)
                throw new Exception("Email no formarto incorreto");


            var mail = new MailMessage
            {
                From = new MailAddress(MyEmail),
                Subject = "Portifolio",
                Body = $"O e-mail {email} entrou em contato com a seguinte mensagem:\n\n{message}"
            };
            mail.To.Add(MyEmail);
            mail.To.Add(email);


            using (var smtp = new SmtpClient("smtp.gmail.com"))
            {
                smtp.EnableSsl = true;
                smtp.Port = 587;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(MyEmail, "umabestalevandochunbodeumxuxuverde#@1234ad 4fb7dfa65 rCCe");
                smtp.Send(mail);
            }

        }
    }
}

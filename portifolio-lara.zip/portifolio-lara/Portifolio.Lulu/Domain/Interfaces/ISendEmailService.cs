﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portifolio.Lulu.Domain.Interfaces
{
    public interface ISendEmailService
    {
        void SendEmail(string email, string message);
    }
}

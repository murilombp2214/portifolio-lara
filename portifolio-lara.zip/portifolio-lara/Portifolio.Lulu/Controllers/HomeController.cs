﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Portifolio.Lulu.Domain.Interfaces;
using Portifolio.Lulu.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Portifolio.Lulu.Controllers
{
    public class HomeController : Controller
    {
        private readonly ISendEmailService _serviceEmail;

        public HomeController(ISendEmailService serviceEmail)
        {
            _serviceEmail = serviceEmail;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpPost("/Home/SendEmail")]
        public IActionResult SendEmail([FromBody] HomeEmailViewModel model)
        {
            try
            {
                _serviceEmail.SendEmail(model.Email, model.Message);
                return Ok(new
                {
                    Erro = false
                });
            }
            catch (Exception erro)
            {
                return Ok(new
                {
                    Erro = true
                });
            }
        }
    }
}
